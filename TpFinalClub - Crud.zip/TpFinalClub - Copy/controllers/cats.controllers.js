// controla si es valido lo que le piden

const catService = require("../services/cats.services");

// funcion para mostrar todos los gatos, los pide al servicio (ANDA)
async function devolverTodos(req, res) {
  const datos = await catService.devolverTodos();
  res.json(datos);
} 

// funcion para devolver por nombre, si no es mayor a 3 va a tirar error (NO ANDA)
async function devolverPorNombre(req, res) {
  let n = req.params.nombre;

  if (!(n.length > 3)) {
    res.status(422).send("El nombre debe ser de mas de 3 letras");
    return;
  }

  try {
    const datos = await catService.devolverPorNombre(n);
    return res.json(datos); // lo retorna en json
  } catch (err) {
    return res.status(204).json({ mensaje: `${n} no encontrado`})
  }
}


// funcion para crear un gato nuevo
async function crear(req, res) {
  let {name,birth,type} = req.body;
  try {
    console.log({req});
    const respuesta = await catService.crear({name,birth,type});
    console.log(respuesta, "edrftvgybhu")
    return res.json({ mensaje: 'Se creo un gato nuevo!!!' });
  } catch (err){
    console.log(err.response.data);
    return res.status(404).json({ mensaje: `faltan completar datos`})
  }
}

// funcion para borrar un gato
async function borrar(req, res) {
  let id = req.params.id;
  try {
  const resee = await catService.borrar(id);
    console.log(resee, "edrftvgybhu")
  res.json({ mensaje: 'Se borro un gato!!!' });
  } catch (err) {
    return res.status(404).json({ mensaje: `${id} no encontrado`})
  }
}

// funcion para modificar un gato
async function modificar(req, res) {
  let cat = req.body;
  let id = req.params.id;
  await catService.modificar(id,cat);
  res.json({ mensaje: 'Se modifico un gato!!!' });
}


module.exports = {
  crear,
  borrar,
  modificar,
  devolverTodos,
  devolverPorNombre,
};
