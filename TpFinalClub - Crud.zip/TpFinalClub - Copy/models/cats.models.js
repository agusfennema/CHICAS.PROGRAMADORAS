// logica de negocio; ej si es mayor de 18 en una aplicacion
// lo    que nos importa que la app haga

  // aca en vez de usar JSON, conecto a la DB
  const CATCOLLECTION = "cats";
  const {pb} = require('./index.models'); // importar la base
  
// funcion para obtener todos los gatoss
async function getCats() {
  return await pb.collection(CATCOLLECTION).getList();
}

// se  comunica con la BD que en este caso seria STORE
async function getCatsByNombre(nombre) {
  return await pb.collection(CATCOLLECTION).getFirstListItem(`name="${nombre}"`, {});
}

async function createCat(cats) {
  let nuevoCat = {
    name: cats.name,
    birth: cats.birth,
    type: cats.type,
  }
  return await pb.collection(CATCOLLECTION).create(nuevoCat);
}


async function deleteCat(id) {
  return await pb.collection(CATCOLLECTION).delete(id);
}


// PATCH / PUT
async function updateCat(id, cat) {
  return await pb.collection(CATCOLLECTION).update(id,cat);
}




module.exports = {
  getCats,
  createCat,
  updateCat,
  deleteCat,
  getCatsByNombre
}



// patch manda y cambia solo los datos que le paso
// put le mandas 3 y si habian 5 te borra las demas xd
