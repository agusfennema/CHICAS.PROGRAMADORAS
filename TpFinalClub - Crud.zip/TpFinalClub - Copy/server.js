let express = require("express");
let bodyParser = require("body-parser");
let app = express();
let path = require("path");
let puerto = 4000;
let rutas = require('./routes/index.routes');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(rutas);

app.use('/public', express.static(path.join(__dirname, 'public')));
// crear una carpeta public, agregar los links de las imagenes a las bases de datos de los gatos

app.listen(puerto, () => {
  console.log(`Server iniciado en puerto: ${puerto}`);
});



// en el router llamas a cada ruta, le asignas a cada ruta cosas especificas a lo relacionas
// una ruta puede tener subrutas adentro 
// en user podrias poner una ruta para ver los cobayos que le pertenen, y las subrutas serian las /__/__/ 