// tiene la funcion de router
const express = require('express');
const router = express.Router();
const catController = require('../controllers/cats.controllers');

router.get("/", catController.devolverTodos);
router.get('/nombre/:nombre', catController.devolverPorNombre);
router.post("/", catController.crear);
router.delete("/:id", catController.borrar);
router.put("/:id", catController.modificar);

// en el router le pasas el metodo que queres usar y la funcion del controlador
// en TC elegis el metodo y automaticamente va a hacer lo que en el router dice

module.exports = router;