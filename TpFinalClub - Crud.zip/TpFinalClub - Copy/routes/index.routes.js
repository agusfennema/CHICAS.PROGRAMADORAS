// ruta de rutas
// llamas a la ruta auth y ruta cats
// router.use("/auth",authRouter); 
// y asi con todas las rutas 


// aca hago un index /cats que llame al cats.routes
const express = require('express');
const router = express.Router();

const catRouter = require('./cats.routes');
;

router.use("/cats",catRouter)

module.exports = router;