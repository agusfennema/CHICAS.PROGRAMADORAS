const catModel = require('../models/cats.models');


// devolver todos los gatos
function devolverTodos() {
  return catModel.getCats();
}

// devolver gato por nombre
async function devolverPorNombre(n) {
  let cats = await catModel.getCatsByNombre(n);
  return cats;
}

// crear un gato
async function crear(cats) {
  console.log({cats});
  return  await catModel.createCat(cats);
}

// obrrar un gato
async function borrar(id) {
  return await catModel.deleteCat(id);
}

// modificar un gato
async function modificar(id, cat) {
  return await catModel.updateCat(id, cat);
}


module.exports = {
  crear,
  modificar,
  borrar,
  devolverTodos,
  devolverPorNombre
}
